# Operar sua rotina diaria com o Copiloto EXECUTAR

## O que resolve
Rotinas de execucao diaria costumam se fragmentar em multiplas fontes (memoria, planilhas,
conversas), gerando estado divergente, retrabalho de replanejamento e perda de continuidade
entre um dia de trabalho e o proximo. O Copiloto EXECUTAR opera sobre uma unica fonte de
verdade e nunca cria plano, fila, progresso ou gate paralelo.

## Como usar
1. Resolver a autoridade operacional no Drive (`EXECUTAR_CONTROL_CENTER` como fonte canonica,
   `00_AGORA` como ponto de entrada humano) antes de qualquer escrita.
2. Rodar `/bomdia` para validar o fechamento anterior, resolver o trabalho liberado e emitir o
   dia.
3. Rodar `/agora` quando precisar apenas do objeto atual, DoD, evidencia esperada e proxima
   acao.
4. Rodar `/estado` para ver progresso derivado, sprint/C72, gate, bloqueios e posicao atual.
5. Ao concluir o trabalho do dia, rodar `/fechardia`: so fecha com DoD atendido, evidencia e
   verificacao simultaneas.
6. Se o escopo mudar, rodar `/replanejamento` para recalcular apenas o subgrafo afetado, salvo
   inconsistencia sistemica.

## Resultado esperado
Um dia de execucao fechado com estado, evidencia e proxima acao registrados na fonte canonica,
sem estados paralelos ou percentuais inventados. A resposta diaria segue o formato:

```
[PROGRESSO] [SPRINT/C72] [GATE]
AGORA: ID — acao
TEMPO: duracao
CONCLUI QUANDO: DoD
EVIDENCIA: prova esperada
PROXIMA: uma acao
```

## Falha segura
Se a autoridade canonica nao puder ser resolvida, ou um requisito critico falhar, o copiloto
nao cria substituto, nao inventa estado e nao promove nada a CONCLUIDO — apenas informa o
bloqueio de forma curta e devolve a acao minima necessaria para recuperar a operacao.
