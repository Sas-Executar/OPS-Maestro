# Evidências — Copiloto EXECUTAR (SOL-COPILOTO-EXECUTAR-001)

## Natureza desta rodada
Nenhuma medição de uso real, teste de usuario ou observacao clinica/cientifica foi realizada
nesta ingestao. O material de entrada e a propria Skill `copiloto-executar` (SKILL.md +
`references/commands.md`, `produtividade.md`, `operacoes.md`, `contracts/*`), nao um estudo de
campo. Por isso, a metodologia SEUS-v0.1 (`evidence_based_scoring`) permanece com todas as
dimensoes em `score: null` — ausencia de medicao nunca vira zero nem estimativa.

## O que e verificavel diretamente do material
- Existe um contrato de estados formal (`references/contracts/state-contract.json`) e um
  contrato de bindings de autoridade Drive (`references/contracts/drive-bindings.json`).
- Existem preflight checks declarados (`references/contracts/preflight-checks.json`) antes da
  primeira escrita de uma instalacao/sessao nao validada.
- Existe um esquema de entrada/saida do orquestrador (`orchestrator-input.schema.json`,
  `orchestrator-output.schema.json`) e um conjunto de testes declarados
  (`orchestrator-tests.json`).
- Os comandos principais e seus IDs verbais estao listados em `commands.md`
  (CV-BOMDIA-001, CV-AGORA-001, CV-ESTADO-001, CV-FECHAR-001, CV-REPLAN-001).

## O que nao e verificavel nesta rodada (permanece null, sem medicao)
- Qualquer reducao de passos, tempo ou carga cognitiva (`steps_reduction`, `time_reduction`,
  `cognitive_load_reduction`): sem baseline/medicao comparavel disponivel.
- Confiabilidade operacional (`reliability`): sem contagem observada de execucoes/sucessos.
- Dor publica, reuso e risco de overkill: exigem benchmark de populacao/coorte, indisponivel.
- Alivio de funcoes executivas: exige instrumento validado (ex.: NASA-TLX ou equivalente);
  nao aplicado.

## Literatura de calibração (benchmark_ref, via web search em 2026-09-21)
Não é medição desta solução — são referências externas citáveis que sustentam a
*plausibilidade do mecanismo* (WIP=1, fonte única de verdade) e servem como `benchmark_ref`
para futura calibração. Nenhum score foi atribuído a partir delas.

| Dimensão | Referência | Natureza |
|---|---|---|
| `public_pain` | [Pieces — "The cost of context switching"](https://pieces.app/blog/cost-of-context-switching) | Conteúdo de indústria (hipótese de dor pública) |
| `public_pain` / `executive_function_relief` | [PMC — "Task Switching: On the Relation of Cognitive Flexibility with Cognitive Capacity"](https://pmc.ncbi.nlm.nih.gov/articles/PMC10140903/) | Artigo científico revisado por pares (mecanismo geral de custo de troca de tarefa) |
| `cognitive_load_reduction` | [NASA — Task Load Index (TLX)](https://www.nasa.gov/human-systems-integration-division/nasa-task-load-index-tlx/) | Instrumento validado oficial (fonte primária) |
| `dependency_burden` | [Document360 — "Single Source of Truth"](https://document360.com/blog/single-source-of-truth/) | Conteúdo de prática de indústria, não estudo controlado |
| `reliability` | [Atlassian — "Working with WIP limits for kanban"](https://www.atlassian.com/agile/kanban/wip-limits) | Conteúdo de prática de indústria, não estudo controlado |

**Nota sobre TDAH/funções executivas clínicas:** a pesquisa também localizou literatura clínica
específica sobre déficit de função executiva em TDAH (ex.: CHOP, PMC — ver busca realizada), mas
ela **não foi anexada** a esta solução porque o material de entrada (`copiloto-executar`) não se
posiciona como ferramenta para TDAH. Anexar essa evidência seria inventar um vínculo/alegação não
declarado no material de origem. Se o usuário confirmar esse posicionamento, `evidence_matrix_18`
pode ser preenchido nessa direção numa próxima rodada.

## Revisões estáticas realizadas
- `store.py validate --stage schema`: **PASS** (sem issues) em 2026-09-21, sobre o snapshot
  fixado no commit `5f1e46b695dbe572c8694f71ff58ebc4f8c76b88`.
- Revisão semântica manual do `solution.yaml` pelo agente de ingestão: consistência de IDs,
  ausência de claims quantitativos não sustentados, e verificação de que nenhuma taxonomia,
  owner, link, teste ou aprovação foi inventado.

## Limite explícito
PASS estático não prova execução real, não avalia qualidade semântica do conteúdo e não
concede autorização de publicação. Qualquer evolução desta seção exige medição real
(observação de uso, teste funcional ou fonte científica/clínica citável), não estimativa.
