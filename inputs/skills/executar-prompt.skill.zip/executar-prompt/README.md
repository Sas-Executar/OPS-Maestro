# Executar Prompt

Skill para transformar e aplicar prompts como especificações operacionais de agentes.

## Instalação no Claude Code

Pessoal:
```bash
mkdir -p ~/.claude/skills
cp -R executar-prompt ~/.claude/skills/executar-prompt
```

Projeto:
```bash
mkdir -p .claude/skills
cp -R executar-prompt .claude/skills/executar-prompt
```

Depois, invoque `/executar-prompt` ou descreva uma tarefa compatível com o `description`.

## Validação

```bash
python3 scripts/validate_skill.py
```

Para validação oficial do Agent Skills spec, quando `skills-ref` estiver instalado:
```bash
skills-ref validate ./executar-prompt
```

## Estrutura

- `SKILL.md`: instruções centrais e trigger.
- `references/`: conhecimento operacional carregado sob demanda.
- `examples/`: exemplos de classificação e execução.
- `evals/`: casos de qualidade e de trigger.
- `scripts/`: validação local.
- `assets/`: contrato-base reutilizável.
