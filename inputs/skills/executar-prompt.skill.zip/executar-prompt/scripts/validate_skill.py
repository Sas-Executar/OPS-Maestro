#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
skill = root / "SKILL.md"

errors = []
if not skill.exists():
    errors.append("SKILL.md ausente")
else:
    text = skill.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        errors.append("frontmatter YAML ausente")
    parts = text.split("---", 2)
    if len(parts) < 3:
        errors.append("frontmatter inválido")
    else:
        fm = parts[1]
        name_match = re.search(r"(?m)^name:\s*([^\s]+)\s*$", fm)
        desc_match = re.search(r"(?ms)^description:\s*(.+?)(?:\n[a-zA-Z][\w-]*:|\Z)", fm)
        if not name_match:
            errors.append("name ausente")
        else:
            name = name_match.group(1).strip()
            if name != root.name:
                errors.append(f"name '{name}' deve corresponder ao diretório '{root.name}'")
            if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
                errors.append("name deve conter apenas minúsculas, números e hífens")
            if len(name) > 64:
                errors.append("name excede 64 caracteres")
        if not desc_match:
            errors.append("description ausente")
        else:
            desc = " ".join(line.strip() for line in desc_match.group(1).splitlines()).strip()
            if len(desc) > 1024:
                errors.append("description excede 1024 caracteres")
    if len(text.splitlines()) > 500:
        errors.append("SKILL.md excede recomendação de 500 linhas")

for rel in [
    "references/prompt-architecture.md",
    "references/execution-policy.md",
    "references/tool-routing.md",
    "references/quality-rubric.md",
    "references/security-and-boundaries.md",
    "examples/examples.md",
    "assets/prompt-contract-template.md",
]:
    if not (root / rel).exists():
        errors.append(f"referência ausente: {rel}")

if errors:
    print("INVALID")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("VALID")
print(f"Skill: {root.name}")
print(f"SKILL.md lines: {len(skill.read_text(encoding='utf-8').splitlines())}")
