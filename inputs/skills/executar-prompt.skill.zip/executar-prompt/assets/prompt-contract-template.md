# Agent Prompt Contract

## OBJECTIVE
[Resultado observável]

## CONTEXT
<context>
[Somente contexto que altera decisões]
</context>

## INPUT
<input>
[Dados/variáveis]
</input>

## CONSTRAINTS
- [Obrigatório]
- [Proibição]
- [Limite]

## TOOLS
- [Ferramenta] → usar quando [condição]; verificar [resultado].

## EXECUTION
1. [Etapa]
2. [Etapa]
3. [Validação]

## OUTPUT CONTRACT
[Formato e campos obrigatórios]

## VALIDATION
- [Critério verificável]

## STOP CONDITIONS
Finalizar quando [condições].
