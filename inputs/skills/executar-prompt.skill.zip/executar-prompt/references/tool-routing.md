# Tool Routing

## Regra

Escolher a ferramenta mais específica capaz de obter ou modificar o recurso real.

## Hierarquia prática

1. Ferramenta/conector nativo do recurso.
2. Ferramenta de busca/leitura especializada.
3. Navegação web para informação pública atual.
4. Shell/script para transformação determinística local.
5. Raciocínio sem ferramenta quando a tarefa não depende de estado externo.

## Antes do uso

Verificar:
- o dado precisa ser atual?
- existe recurso privado/conectado?
- a ação modifica estado externo?
- a ferramenta suporta exatamente a operação?
- existe uma alternativa mais específica?

## Depois do uso

Validar:
- retorno corresponde ao recurso solicitado;
- não há resultado parcial tratado como completo;
- IDs, caminhos, datas e nomes estão consistentes;
- falhas/ausência de resultado não são convertidas em fatos.

## Ações externas

Para envio, publicação, exclusão, compra, deploy ou alteração irreversível:
- respeitar permissões do ambiente;
- limitar ao escopo pedido;
- não ampliar destinatários/efeitos;
- relatar resultado real, não intenção.

## Scripts

Usar scripts para:
- validação determinística;
- transformação repetitiva;
- checks que não devem depender de interpretação do modelo.

Não criar script temporário quando uma ferramenta padrão resolve diretamente.
