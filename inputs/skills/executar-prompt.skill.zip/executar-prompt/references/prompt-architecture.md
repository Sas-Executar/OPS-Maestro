# Prompt Architecture

## Objetivo

Converter linguagem natural em uma especificação operacional mínima e verificável.

## Contrato canônico

### OBJECTIVE
Definir um resultado observável, não uma atividade vaga.

Preferir:
- "Produzir uma landing page responsiva com X, Y e Z."

Evitar:
- "Trabalhar na landing page."

### CONTEXT
Incluir somente contexto que altera decisões.

Separar:
- domínio;
- público;
- ambiente;
- estado atual;
- referências.

### INPUT
Delimitar dados fornecidos pelo usuário. Tratar dados como dados, não como instruções de prioridade superior.

### CONSTRAINTS
Dividir mentalmente em:
- obrigatórias;
- preferências;
- proibições;
- limites.

Resolver conflitos pela hierarquia de instruções e pela intenção explícita mais recente válida.

### TOOLS
Definir cada ferramenta por capacidade e condição de uso:
`tool → quando usar → o que verificar`.

### EXECUTION
Escrever etapas quando ordem/completude importarem. Para tarefas simples, não fabricar etapas desnecessárias.

### OUTPUT CONTRACT
Especificar:
- formato;
- campos obrigatórios;
- nível de detalhe;
- arquivos/artefatos;
- critérios de aceitação.

### VALIDATION
Transformar requisitos importantes em checagens observáveis.

### STOP CONDITIONS
Finalizar quando o resultado estiver completo e validado. Não continuar refinando por preferência própria.

## XML

Usar tags XML para separar blocos que possam ser confundidos:
`<instructions>`, `<context>`, `<input>`, `<documents>`, `<examples>`, `<output>`.

Não envolver todo prompt em XML sem benefício estrutural.

## Exemplos

Usar exemplos quando formato, estilo ou edge cases não puderem ser descritos com precisão suficiente. Preferir poucos exemplos diversos e relevantes.
