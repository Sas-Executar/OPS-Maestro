# Quality Rubric

Avaliar cada dimensão de 0 a 2.

## 1. Fidelidade
0: mudou o objetivo.
1: objetivo atendido parcialmente.
2: objetivo e restrições preservados.

## 2. Completude
0: faltam partes centrais.
1: há lacunas menores.
2: entregável completo.

## 3. Grounding
0: contém invenções materiais.
1: algumas afirmações sem verificação suficiente.
2: fatos e recursos estão verificados ou claramente qualificados.

## 4. Executabilidade
0: saída não pode ser usada.
1: exige correções manuais relevantes.
2: pronta para uso.

## 5. Eficiência
0: overengineering ou desvio.
1: algum excesso.
2: solução proporcional e direta.

## 6. Formato
0: viola formato pedido.
1: pequenas inconsistências.
2: formato correto e consistente.

### Gate
Não finalizar com nota 0 em Fidelidade, Grounding ou Executabilidade.

Para tarefas críticas, buscar pelo menos 10/12 e corrigir dimensões fracas antes da entrega.
