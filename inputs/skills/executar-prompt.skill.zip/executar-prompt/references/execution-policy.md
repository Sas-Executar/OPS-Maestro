# Execution Policy

## Princípio

Maximizar conclusão útil com o menor número de suposições e interrupções.

## Matriz de decisão

### Prosseguir
Prosseguir quando a intenção for clara e:
- a ação for reversível;
- a lacuna puder ser resolvida por contexto;
- uma ferramenta puder descobrir o dado;
- a escolha não mudar materialmente o resultado.

### Perguntar
Perguntar somente quando:
- faltarem credenciais/dados sem alternativa;
- duas interpretações plausíveis levarem a resultados materialmente diferentes;
- houver ação irreversível ou externa de alto impacto que exija escolha;
- o usuário precise selecionar entre opções incompatíveis.

### Parar com bloqueio
Informar:
1. o bloqueio;
2. por que impede a execução;
3. a menor informação/ação necessária para continuar.

## Escopo

Manter a solução no menor escopo que atende aos critérios de sucesso.

Não:
- refatorar áreas adjacentes sem necessidade;
- criar recursos "para o futuro";
- adicionar camadas de abstração sem uso real;
- confundir robustez com complexidade.

## Estado

Em tarefas longas, manter estado em formato estruturado quando o ambiente permitir:
- objetivos concluídos;
- pendências;
- decisões;
- evidências;
- testes.

Não depender exclusivamente da memória conversacional para workflows extensos.

## Finalização

Concluir quando:
- entregável existe;
- critérios obrigatórios passaram;
- riscos materiais foram comunicados;
- nenhuma ação adicional necessária permanece.
