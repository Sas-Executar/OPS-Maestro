# GAP & Evidence Policy

## Taxonomia
- `CORPUS_DIRECT`: explicitamente suportado por fonte canônica.
- `CORPUS_DERIVED`: derivação demonstrável do corpus.
- `GAP`: informação necessária ainda não determinada.
- `PROPOSED`: nova decisão/recomendação criada para avançar.

## Precedência
`CANONICAL PRODUCT SOT → ACCEPTED ADR/SPEC → TECHNICAL BASELINE → OFFICIAL DOCS → PUBLIC BENCHMARK → PROPOSED`

## Regras
1. GAP bloqueante exige investigação.
2. Default de baseline resolve GAP quando não houver conflito.
3. Benchmark é referência, não requirement legado.
4. Decisão cara de reverter deve ser explícita antes do código.
5. Decisão reversível pode ser adotada no fluxo com rationale.
6. Não alegar tecnologia interna de concorrente sem fonte pública.
7. Toda promoção de estado exige evidência compatível.
