# Product Management Capabilities — síntese integrada

Estas capacidades são adaptação funcional, não cópia dos arquivos do plugin original.

## PM01 · Product Brainstorming
Comece pelo problema, não pela solução preferida. Explore hipóteses, JTBD, First Principles, How Might We e árvores de oportunidade. Separe ideias de decisões.

## PM02 · Synthesize Research
Agrupe entrevistas, tickets, surveys, analytics e observações em temas. Preserve evidência contraditória. Distinga frequência, severidade, segmento e confiança.

## PM03 · Competitive Brief
Pesquise concorrentes e adjacentes. Compare comportamento, posicionamento, fluxos, pricing público, integrações e capacidades observáveis. Não inferir arquitetura privada.

## PM04 · Write Spec
Transforme problema em spec implementável: objetivo, usuários, contexto, IN/OUT, requirements, constraints, dependencies, AC, success metrics, risks e open questions.

## PM05 · Roadmap Update
Organize outcomes/iniciativas por Now/Next/Later ou horizonte equivalente. Inclua dependências, evidência, impacto, confiança e capacidade.

## PM06 · Sprint Planning
Converta prioridade em escopo curto com objetivo, tarefas elegíveis, dependências, capacidade, riscos e DoD. Prefira vertical slices com valor observável.

## PM07 · Metrics Review
Defina/avalie árvore de métricas, metas, tendência, segmentação, guardrails e aprendizado. Não misture hipótese com métrica observada.

## PM08 · Stakeholder Update
Adapte a comunicação ao público. Inclua progresso verificável, decisões, mudanças de escopo, riscos, métricas e próximos milestones. Não inflar estado.
