# Source Manifest

Esta skill é síntese/orquestração original baseada nas capacidades públicas dos plugins Anthropic Knowledge Work e no padrão atual de Claude Code Skills.

## Anthropic Knowledge Work Plugins
- Engineering: https://github.com/anthropics/knowledge-work-plugins/tree/main/engineering
- Engineering skills: https://github.com/anthropics/knowledge-work-plugins/tree/main/engineering/skills
- Product Management: https://github.com/anthropics/knowledge-work-plugins/tree/main/product-management
- Product Management skills: https://github.com/anthropics/knowledge-work-plugins/tree/main/product-management/skills

Capacidades observadas:
- Engineering: architecture, code-review, debug, deploy-checklist, documentation, incident-response, standup, system-design, tech-debt, testing-strategy.
- Product Management: competitive-brief, metrics-review, product-brainstorming, roadmap-update, sprint-planning, stakeholder-update, synthesize-research, write-spec.

## Claude Code / Agent Skills
- Skills: https://code.claude.com/docs/en/slash-commands
- .claude directory: https://code.claude.com/docs/en/claude-directory
- Plugins: https://code.claude.com/docs/en/plugins-reference

## Proveniência
Os arquivos deste pacote são workflows e sínteses originais. Não vendorizam nem reproduzem integralmente os SKILL.md da Anthropic.
