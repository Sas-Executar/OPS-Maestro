# Decision — {{TITLE}}

Status: `PROPOSED`

## Context
{{GAP/problema}}

## Evidence
- SOT:
- baseline:
- official docs:
- benchmark:

## Options
1. ...
2. ...

## Decision
{{escolha}}

## Rationale
{{trade-offs}}

## Reversibility
`LOW | MEDIUM | HIGH COST TO REVERSE`

## Implementation impact
{{paths/components/migrations}}

## Verification
{{como validar}}
