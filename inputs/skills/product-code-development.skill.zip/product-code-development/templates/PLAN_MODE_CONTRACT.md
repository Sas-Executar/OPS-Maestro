# {{PRODUCT_OR_FEATURE}} — CODE IMPLEMENTATION PLAN

## OBJECTIVE
{{resultado técnico observável}}

## REPOSITORY ROLES
SOT: `{{SOT_REPO}}` — READ
Target: `{{IMPLEMENTATION_REPO}}` — PLAN / CODE / TEST / DEPLOY
Baseline: `{{BASELINE}}`

## CURRENT CODEBASE ASSESSMENT
{{estado real}}

## TARGET RUNTIME ARCHITECTURE
{{arquitetura final}}

## BLOCKING DECISIONS
{{somente decisões caras de reverter ou bloqueantes}}

## MILESTONES
Para cada milestone:
- Objective
- Source Requirements
- Target Paths
- Implementation
- Dependencies
- AC
- Verification
- Evidence

## CRITICAL PATH
{{sequência estritamente dependente}}

## PARALLEL WORKSTREAMS
{{trilhas seguras}}

## GAPS / RISKS
{{GAP + resolução ou tratamento}}

## DEFINITION OF DONE
{{gates}}

## DEFINITION OF PRODUCT COMPLETE
{{produto final}}

## FIRST IMPLEMENTATION TASK
Primeira alteração concreta de código, paths, motivo, dependências, testes e milestone.
