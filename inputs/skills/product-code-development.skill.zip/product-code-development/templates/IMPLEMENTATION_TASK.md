# {{TASK_ID}} — {{TITLE}}

## Objective
{{comportamento técnico que passará a existir}}

## Source Requirements
{{IDs/fontes}}

## Target Repository
`{{repo}}`

## Target Paths
- `{{path}}`

## Implementation
{{mudança de código}}

## Dependencies
{{dependências}}

## Acceptance Criteria
- AC-01:
- AC-02:

## Verification
- format:
- lint:
- typecheck:
- tests:
- build:
- integration/smoke:

## Evidence
{{artefato/log/teste/estado observável}}
