# HANDOFF — {{MILESTONE_OR_RELEASE}}

Status: `{{IMPLEMENTED|TESTED|VERIFIED|DEPLOYED|RELEASED}}`

## Delivered
- ...

## Changed Paths
- ...

## Requirements / AC
- ...

## Verification Executed
- ...

## Evidence
- ...

## Known Gaps / Risks
- ...

## Next Eligible Action
- ...
