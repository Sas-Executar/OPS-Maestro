# WF-05 — Review & Debug

## Review — ENG03
Leia diff + contexto; procure correctness/data integrity, segurança/autorização, performance, falhas/retries/idempotency, edge cases, compatibilidade e testes ausentes. Classifique BLOCKER / HIGH / MEDIUM / LOW / NOTE.

## Debug — ENG04
`reproduzir → capturar evidência → formar hipóteses → isolar → causa raiz → menor correção → regression test → verificar fluxo completo`.

Não altere código aleatoriamente para “ver se passa”.
