# WF-00 — Session Intake

1. Detecte modo.
2. Identifique SOT e implementation repo.
3. Leia instruções locais.
4. Inspecione código/Git.
5. Defina outcome observável.
6. Liste constraints e gates.
7. Classifique gaps.
8. Selecione capabilities.
9. Escolha workflow.
10. Termine com FIRST NEXT ACTION.

Saída mínima:
`MODE | SOT | TARGET | BASELINE | CURRENT STATE | OUTCOME | CONSTRAINTS | WORKFLOW | NEXT ACTION`
