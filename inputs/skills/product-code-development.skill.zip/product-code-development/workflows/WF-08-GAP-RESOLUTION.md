# WF-08 — GAP Resolution

1. Declare exatamente o GAP.
2. Classifique produto, arquitetura ou detalhe reversível.
3. Pesquise corpus/SOT.
4. Verifique baseline/default.
5. Consulte documentação oficial atual.
6. Use web research e benchmark público se necessário.
7. Compare adequação, reversibilidade, complexidade, segurança, manutenção e custo quando material.
8. Escolha solução mais sustentada.
9. Classifique como PROPOSED se nova.
10. ADR antes do código se difícil/caro de reverter.
11. Se reversível, registre rationale na task/PR e implemente.
12. Verifique com teste/evidência.

Não deixe GAP bloqueante aberto por omissão. Não invente arquitetura privada de concorrentes.
