# WF-03 — Code Implementation Plan

Use em Plan Mode.

## Proibição
Não produza plano cuja maioria seja ADR/README/checklist. O objeto é futura modificação de código.

## Sequência
1. Current Codebase Assessment.
2. Target Runtime Architecture.
3. Blocking Decisions.
4. Milestones orientados a artefatos executáveis.
5. Tasks com paths.
6. Critical path.
7. Parallel workstreams.
8. Risks/GAPs.
9. Verification.
10. Definition of Done.
11. Definition of Product Complete.
12. FIRST IMPLEMENTATION TASK.

Cada milestone deve resultar em ao menos um: code, package, app, schema, migration, API, adapter, job, MCP/AI runtime, test/eval, runtime config, CI/CD ou infra.

Use `templates/PLAN_MODE_CONTRACT.md`.
