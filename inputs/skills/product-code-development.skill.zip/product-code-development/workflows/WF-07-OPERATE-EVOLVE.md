# WF-07 — Operate & Evolve

Capabilities: ENG08 + ENG09 + ENG10 + ENG07 + PM07 + PM08 + PM05.

Loop:
`OBSERVE → METRICS REVIEW → INCIDENT/DEBUG IF NEEDED → STANDUP → TECH-DEBT → LEARNING → ROADMAP UPDATE → STAKEHOLDER UPDATE`

Incidente: estabilize primeiro. Métricas: diferencie observação de hipótese. Tech debt: priorize por risco/impacto. Documentation: sincronize com comportamento verificado. Roadmap: incorpore aprendizado real.
