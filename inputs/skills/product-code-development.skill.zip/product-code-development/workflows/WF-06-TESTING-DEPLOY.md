# WF-06 — Testing & Deploy

Capabilities: ENG05 + ENG06.

## Testing Strategy
Mapeie riscos para unit, integration, contract, E2E, database/RLS, security, performance, accessibility, AI evals e mobile/device quando aplicável.

## Deploy Gate
Confirme review, typecheck/lint/build, tests/evals, migrations, env/secrets, compatibility, observability/alerts, health/smoke, rollback e known risks.

Resultado: `PASS | FAIL | BLOCKED`.

Deploy concluído não equivale a release verificado.
