# WF-04 — Vertical Slice Build

1. Escolha a menor fatia que atravesse as camadas necessárias.
2. Verifique dependências e AC.
3. Implemente domain/contracts antes de acoplar providers.
4. Implemente persistence/API/UI suficientes para fluxo end-to-end.
5. Instrumente erros e observabilidade relevante.
6. Escreva testes conforme risco.
7. Execute quality gates.
8. Corrija regressões no escopo.
9. Registre evidência.
10. Só então promova estado.

Evite desenvolvimento horizontal sem necessidade. Prefira comportamento demonstrável ponta a ponta.
