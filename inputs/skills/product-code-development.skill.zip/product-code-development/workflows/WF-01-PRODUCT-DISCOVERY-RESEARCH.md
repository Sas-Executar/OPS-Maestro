# WF-01 — Product Discovery & Research

Capabilities: PM01 + PM02 + PM03 + PM04 quando necessário.

1. Reformule problema e usuário afetado.
2. Consulte evidência interna antes de idear.
3. Sintetize pesquisa sem apagar contradições.
4. Pesquise benchmark apenas para gaps relevantes.
5. Explore alternativas e hipóteses.
6. Identifique hipótese mais arriscada e menor validação.
7. Se seguir para build, gere requirements/AC suficientes para arquitetura/system design.
8. Classifique novidade como PROPOSED.

Saída: `Problem → Evidence → Opportunities → Alternatives → Recommendation/Experiment → Requirements handoff`.
