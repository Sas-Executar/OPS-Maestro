# WF-09 — Product-to-Production

1. WF-00 Session Intake.
2. WF-01 discovery/research apenas até haver problema/requisitos suficientes.
3. WF-02 architecture/system design para decisões estruturais.
4. WF-03 Code Implementation Plan.
5. PM05/PM06: ordenar roadmap e sprint executável.
6. WF-04: construir vertical slice.
7. WF-05: review/debug.
8. WF-06: testing + deploy gate.
9. Deploy conforme gate.
10. WF-07: métricas, feedback, incidentes, dívida e roadmap.
11. Iterar.

Princípio: `DISCOVERY SUFICIENTE → CODE → EVIDENCE → LEARNING`, não `DOCUMENTAÇÃO TOTAL → CÓDIGO MUITO TARDE`.
