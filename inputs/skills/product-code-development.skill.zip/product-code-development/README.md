# Product Code Development Skill

Skill composta para Claude Code, orientada ao ciclo completo de Product Management + Software Engineering.

## Instalação pessoal

Copie o diretório `product-code-development` para:

`~/.claude/skills/product-code-development/`

Invoque com:

`/product-code-development <missão>`

## Instalação por projeto

Copie para:

`.claude/skills/product-code-development/`

## Estrutura

- `SKILL.md` — roteador/instruções centrais.
- `SESSION_GUIDE_BASE.md` — primeira leitura e entendimento da sessão.
- `references/` — capabilities, evidência e fontes.
- `workflows/` — procedimentos integrados.
- `templates/` — contratos de plan/task/decision/handoff.
- `examples/` — invocações.
- `scripts/validate_skill.py` — valida estrutura e links Markdown locais.

## Filosofia

Product Management e Engineering permanecem conectados, mas Plan Mode nunca vira “plano de documentação”. O fluxo privilegia decisões estruturais suficientes, arquitetura final, vertical slices, verificação contínua e aprendizado de produção.
