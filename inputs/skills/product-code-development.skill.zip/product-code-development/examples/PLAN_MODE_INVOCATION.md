# Exemplos de invocação

## Produto inteiro
`/product-code-development Planeje o desenvolvimento full-stack deste produto. Use ./docs como SOT e este repositório como implementation target. Preserve o starter adotado e use vertical slices.`

## Feature
`/product-code-development Planeje a implementação da capability de notificações descrita no PRD-017. Quero um CODE IMPLEMENTATION PLAN com paths e primeira task.`

## Execução
`/product-code-development Implemente a primeira task elegível do milestone M04, rode os testes aplicáveis e entregue evidências.`

## Review
`/product-code-development Revise este PR com foco em correctness, auth, data integrity, performance e regressões.`

## GAP
`/product-code-development A estratégia de realtime não está definida. Resolva o GAP com SOT, defaults, documentação oficial e benchmark; registre a decisão proposta e diga o impacto no código.`
